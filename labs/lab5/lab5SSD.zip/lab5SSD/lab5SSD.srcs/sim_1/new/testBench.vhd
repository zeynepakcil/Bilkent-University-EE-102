library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity testBench is
--  Port ( );
end testBench;

architecture Behavioral of testBench is

    signal reset   : std_logic;
    signal clk     : std_logic;
    signal anode   : std_logic_vector(3 downto 0);
    signal cathode : std_logic_vector(6 downto 0);
    
    component main is
      Port (clk     : in std_logic; 
            reset   : in std_logic; 
            anode   : out std_logic_vector(3 downto 0);
            cathode : out std_logic_vector(6 downto 0));
    end component;
    
begin
    uut: main port map(clk => clk, reset => reset, anode => anode, cathode => cathode);
        
    
    
    clockProcess: process begin
        clk <= '0';
        wait for 10 ns;
        clk <= '1';
        wait for 10 ns;
    end process;
    
    stimulusProcess: process begin
        reset <= '1';
        wait for 20 ns;
        reset <= '0';
        wait;
    end process;  
    

    
end Behavioral;
