library IEEE;
use IEEE.NUMERIC_STD;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity segmentController is
    Port (clk       : in std_logic;
          reset     : in std_logic;
          clkEnable : in std_logic;
          converter : in std_logic_vector(1 downto 0);
          number    : in std_logic_vector(15 downto 0);
          anode     : out std_logic_vector(3 downto 0);
          cathode   : out std_logic_vector(6 downto 0));
end segmentController;

architecture Behavioral of segmentController is
    signal binaryNumber : std_logic_vector(3 downto 0);
begin

    process(converter) begin
        case converter is
            when "00" => anode <= "0111"; -- activates first segment
            binaryNumber <= number(15 downto 12);
            when "01" => anode <= "1011"; -- activates second segment
            binaryNumber <= number(11 downto 8);
            when "10" => anode <= "1101"; -- activates third segment
            binaryNumber <= number(7 downto 4);
            when "11" => anode <= "1110"; -- activates fourth segment
            binaryNumber <= number(3 downto 0);
            when others => anode <= "1111";
        end case;
    end process;
    
    process(binaryNumber) begin        
        case binaryNumber is
            when "0000" => cathode <= "0000001";  -- 0
            when "0001" => cathode <= "1001111";  -- 1 
            when "0010" => cathode <= "0010010";  -- 2 
            when "0011" => cathode <= "0000110";  -- 3 
            when "0100" => cathode <= "1001100";  -- 4 
            when "0101" => cathode <= "0100100";  -- 5 
            when "0110" => cathode <= "0100000";  -- 6 
            when "0111" => cathode <= "0001111";  -- 7 
            when "1000" => cathode <= "0000000";  -- 8 
            when "1001" => cathode <= "0000100";  -- 9 
            when "1010" => cathode <= "0000010";  -- a 
            when "1011" => cathode <= "1100000";  -- b 
            when "1100" => cathode <= "0110001";  -- c 
            when "1101" => cathode <= "1000010";  -- d 
            when "1110" => cathode <= "0110000";  -- e 
            when "1111" => cathode <= "0111000";  -- f 
            when others => cathode <= "1111111";  
        end case;
    end process;

end Behavioral;
