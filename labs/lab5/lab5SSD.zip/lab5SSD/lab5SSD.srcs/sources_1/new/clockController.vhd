library IEEE;
use IEEE.NUMERIC_STD;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity clockController is
    Port (clk        : in std_logic;
          reset      : in std_logic;
          clkEnable  : out std_logic;
          converter  : out std_logic_vector(1 downto 0);
          sec        : out std_logic_vector(15 downto 0);
          clkCounter : out std_logic_vector(27 downto 0));
end clockController;

architecture Behavioral of clockController is
    
    signal ssec        : std_logic_vector(15 downto 0) := (others => '0'); 
    signal sclkCounter : std_logic_vector(27 downto 0);

begin
    process(clk) begin
        if(reset = '1') then
            sclkCounter <= (others => '0');
            ssec <= (others => '0');
        else
            if rising_edge(CLK) then
            sclkCounter <= sclkCounter + '1';
            
            if sclkCounter =x"5F5E0FF" then
            ssec <= ssec + '1';
            sclkCounter <= (others => '0');
            
            end if;
            end if;
        end if;
    end process;

    clkEnable <= '1' when sclkCounter = x"5F5E0FF" else '0';
    converter <= sclkCounter(19 downto 18);
    clkCounter <= sclkCounter;
    sec <= ssec;


end Behavioral;
