library IEEE;
use IEEE.NUMERIC_STD;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity main is
   Port (clk     : in std_logic; 
         reset   : in std_logic; 
         anode   : out std_logic_vector(3 downto 0);
         cathode : out std_logic_vector(6 downto 0));
end main;

architecture Behavioral of main is
     
     signal clkEnable : std_logic;
     signal converter : std_logic_vector(1 downto 0);
     signal number    : std_logic_vector(15 downto 0);
    
     component clockController is
         Port (clk        : in std_logic;
               reset      : in std_logic;
               clkEnable  : out std_logic;
               converter  : out std_logic_vector(1 downto 0);
               sec        : out std_logic_vector(15 downto 0);
               clkCounter : out std_logic_vector(27 downto 0));
     end component;

     component segmentController is
         Port (clk       : in std_logic;
               reset     : in std_logic;
               clkEnable : in std_logic;
               converter : in std_logic_vector(1 downto 0);
               number    : in std_logic_vector(15 downto 0);
               anode     : out std_logic_vector(3 downto 0);
               cathode   : out std_logic_vector(6 downto 0));
     end component;

begin
    
    CC: clockController port map(clk => clk, reset => reset, clkEnable => clkEnable, converter => converter, sec => number); 
    SC: segmentController port map(clk => clk, reset => reset, clkEnable => clkEnable, converter => converter, number => number, anode => anode, cathode => cathode);
    
end Behavioral;
